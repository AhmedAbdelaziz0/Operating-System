#!/bin/bash

DEST_PATH="$HOME/TURBOC3"
for f in *.C; do
  cp "$(pwd)/$f" "$DEST_PATH/MAIN.C"
done

cd "$DEST_PATH"

dosbox
