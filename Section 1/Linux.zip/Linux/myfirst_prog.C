void main() {
 printf("%s", "Hello world\n");
}
