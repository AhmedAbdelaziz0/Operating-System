Install dosbox. e.g. in Arch linux : 
```shell
sudo pacman -S dosbox
```
Extract TURBOC3 in your HOME dir.
copy dosbox.conf to ~/.dosbox/dosbox-0.74-3.conf after opening dosbox for first time to make the default config be generated.
```shell
chmod +x compile.sh
```
run ``./compile.sh`` in the same dir of your .C file to be compiled and run.
