[Install]
install TurboC++

if you installed the program in any folder other than the defulat please modify the `compile` file and dosbox.conf file
* in `compile` file you should modify the path 
* in dosbox.conf in autoexec section change `mount C: C:\turb..` to your path

copy "dosbox.conf" into TurboC++ installation.


[Usage]
make new directory
copy compile file into that directory
make new file with .c extension
use your favourate IDE to writ the code
then run the compile script
happy coding!