void main() {
 printf("%s", "Hello From OS\n");
}